package ru.macelevels;

import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public final class MaceLevels extends JavaPlugin {

    @Override
    public void onEnable() {
        saveDefaultConfig();

        MaceItem maces = new MaceItem(this);
        getServer().getPluginManager().registerEvents(new MaceListener(this, maces), this);

        PluginCommand cmd = getCommand("mace");
        if (cmd != null) {
            MaceCommand handler = new MaceCommand(this, maces);
            cmd.setExecutor(handler);
            cmd.setTabCompleter(handler);
        }
    }
}
