package ru.macelevels;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** /булава — узнать уровень или получить булаву, если её нет. Админам: give, reload. */
public final class MaceCommand implements TabExecutor {

    private static final String ADMIN = "macelevels.admin";

    private final MaceLevels plugin;
    private final MaceItem maces;

    public MaceCommand(MaceLevels plugin, MaceItem maces) {
        this.plugin = plugin;
        this.maces = maces;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage("Только для игроков.");
                return true;
            }
            int level = maces.findLevel(p);
            if (level > 0) {
                p.sendMessage(Text.mm("<gray>Твоя булава: уровень <white>" + level + "<dark_gray>/" + MaceItem.MAX_LEVEL));
            } else if (maces.give(p, 1)) {
                p.sendMessage(Text.mm("<green>Булава 1 уровня выдана."));
            } else {
                p.sendMessage(Text.mm("<red>Освободи место в инвентаре и попробуй снова."));
            }
            return true;
        }

        if (!sender.hasPermission(ADMIN)) {
            sender.sendMessage(Text.mm("<red>Нет прав."));
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadConfig();
                maces.reload();
                sender.sendMessage(Text.mm("<green>Конфиг перезагружен."));
            }
            case "give" -> {
                if (args.length < 2) {
                    sender.sendMessage(Text.mm("<gray>Использование: <white>/mace give [ник] [уровень 1-8]"));
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) {
                    sender.sendMessage(Text.mm("<red>Игрок не в сети."));
                    return true;
                }
                int level = 1;
                if (args.length >= 3) {
                    try {
                        level = Integer.parseInt(args[2]);
                    } catch (NumberFormatException ex) {
                        sender.sendMessage(Text.mm("<red>Уровень — число от 1 до " + MaceItem.MAX_LEVEL + "."));
                        return true;
                    }
                }
                level = Math.max(1, Math.min(MaceItem.MAX_LEVEL, level));
                if (maces.give(target, level)) {
                    sender.sendMessage(Text.mm("<green>Булава " + level + " уровня выдана игроку <white>" + target.getName()));
                } else {
                    sender.sendMessage(Text.mm("<red>У игрока нет места в инвентаре."));
                }
            }
            default -> sender.sendMessage(Text.mm("<gray>/mace give [ник] [уровень] <dark_gray>• <gray>/mace reload"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        List<String> out = new ArrayList<>();
        if (!sender.hasPermission(ADMIN)) {
            return out;
        }
        if (args.length == 1) {
            for (String s : List.of("give", "reload")) {
                if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
                    out.add(s);
                }
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("give")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))) {
                    out.add(p.getName());
                }
            }
        }
        return out;
    }
}
