package ru.macelevels;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

final class Text {

    private static final MiniMessage MM = MiniMessage.miniMessage();

    private Text() {
    }

    static Component mm(String mini) {
        return MM.deserialize(mini);
    }
}
